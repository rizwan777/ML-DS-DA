import requests
import json
from flask_restful import  Resource
from flask import jsonify
class Temprature(Resource):

      def get(self, city, methods =['GET']):
        area = city
        url1 = ("http://api.openweathermap.org/data/2.5/weather?q=" + area + "&appid=d4514c045821c9e1353b99cef776cae5")
        #url= str(app + city + app_key)
        send = requests.get(url1).json()
        sky = send['weather'][0]['main']
        temp_temp = send['main']['temp']
        temp = int(temp_temp) - 273
        lw_tmp = send['main']['temp_min']
        min_tmp = int(lw_tmp) - 280

        deta_temp = ("the weather in " + str(area) + " city, right now temprature  is " + str(
            temp) + " Celcius and sky is " + str(sky) + ",  In the night lowest temprature " + str(
            min_tmp) + " Celcius will be noted.")
        return jsonify({'result':deta_temp})