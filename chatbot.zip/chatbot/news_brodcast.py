import requests
import json
from flask_restful import Resource
from flask import jsonify

class NEWsUPdate(Resource):
    def tech_news(self):
        url ="https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=804edb8a03d841999ed94576310f5484"
        contents = (requests.get(url).json())
        #b = json.dumps(contents)
        check_status=contents['status']
        news_provider_name = contents['articles'][0]["source"]["name"]
        news_headline =contents['articles'][0]['title']
        news_description =contents['articles'][0]['description']
        news_image=contents['articles'][0]['urlToImage']
        news_speak = "News According to " + news_provider_name + " to days breaking news is " + news_headline + " and in detail " + news_description
        return jsonify({'result': {'status': check_status,
                                   'news_Porvider_Name': news_provider_name,
                                   'news_Headline ': news_headline,
                                   'news_description': news_description,
                                   'news_image_URL_source': news_image,
                                   'speak_news': news_speak}})

    def sport_news(self):
        url = "https://newsapi.org/v2/top-headlines?sources=bbc-sport&apiKey=804edb8a03d841999ed94576310f5484"
        contents = (requests.get(url).json())
        # b = json.dumps(contents)
        check_status = contents['status']
        news_provider_name = contents['articles'][0]["source"]["name"]
        news_headline = contents['articles'][0]['title']
        news_description = contents['articles'][0]['description']
        news_image = contents['articles'][0]['urlToImage']
        news_speak = "News According to " + news_provider_name + " to days breaking news is " + news_headline + " and in detail " + news_description
        return jsonify({'result': {'status': check_status,
                                   'news_Porvider_Name': news_provider_name,
                                   'news_Headline': news_headline,
                                   'news_description': news_description,
                                   'news_image_URL_source': news_image,
                                   'speak_news': news_speak}})


    def china_news(self):
        url = "https://newsapi.org/v2/top-headlines?country=cn&apiKey=804edb8a03d841999ed94576310f5484"
        contents = (requests.get(url).json())
        # b = json.dumps(contents)
        check_status = contents['status']
        news_provider_name = contents['articles'][0]["source"]["name"]
        news_headline = contents['articles'][0]['title']
        news_description = contents['articles'][0]['description']
        news_image = contents['articles'][0]['urlToImage']
        news_speak = "News According to " + news_provider_name + " to days breaking news is " + news_headline + " and in detail " + news_description
        return jsonify({'result': {'status': check_status,
                                   'news_Porvider_Name': news_provider_name,
                                   'news_Headline': news_headline,
                                   'news_description': news_description,
                                   'news_image_URL_source': news_image,
                                   'speak_news': news_speak}})

    def US_news(self):
        url = "https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=804edb8a03d841999ed94576310f5484"
        contents = (requests.get(url).json())
        # b = json.dumps(contents)
        check_status = contents['status']
        news_provider_name = contents['articles'][7]["source"]["name"]
        news_headline = contents['articles'][7]['title']
        news_description = contents['articles'][7]['description']
        news_image = contents['articles'][7]['urlToImage']
        news_speak = "News According to " + news_provider_name + " to days breaking news is " + news_headline + " and in detail " + news_description
        return jsonify({'result': {'status': check_status,
                                   'news_Porvider_Name': news_provider_name,
                                   'news_Headline': news_headline,
                                   'news_description': news_description,
                                   'news_image_URL_source': news_image,
                                   'speak_news': news_speak}})
    def market_Watch(self):
        url = "https://newsapi.org/v2/everything?domains=wsj.com&apiKey=804edb8a03d841999ed94576310f5484"
        contents = (requests.get(url).json())
        # b = json.dumps(contents)
        check_status = contents['status']
        news_provider_name = contents['articles'][7]["source"]["name"]
        news_headline = contents['articles'][7]['title']
        news_description = contents['articles'][7]['description']
        news_image = contents['articles'][7]['urlToImage']
        news_speak = "Todays market According to " + news_provider_name + " to days breaking news is " +news_headline +" and in detail "+news_description
        return jsonify({'result': {'status': check_status,
                                   'news_Porvider_Name': news_provider_name,
                                   'news_Headline': news_headline,
                                   'news_description': news_description,
                                   'news_image_URL_source': news_image,
                                   'speak_news': news_speak}})

