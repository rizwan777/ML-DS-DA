import re

string_test='''
Tom has 2 cars, and Jack have Rock 3 bikes, 3 cars , and 1 helicopter
while Michal have 4 cars and 3 ,Jack ,Sparrow.

'''

name = re.findall(r'[A-Z][a-z]*',string_test)
Vehicals = re.findall(r'\d[1,2]?',string_test)
ls = re.findall(r'\d(.*?)',string_test)
print(name,Vehicals,ls)

num_vehical ={}
x=0
for each_data in name:
    num_vehical[each_data] = Vehicals[x]
    x+=1

print(num_vehical)
print(num_vehical['Sparrow'])
