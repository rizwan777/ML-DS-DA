import wikipedia
import json
from flask_restful import Resource
from flask import jsonify
global flag
flag = 'normal'
class Word2Data(Resource):
    def get(self,word , methods=["GET"]):
        data = wikipedia.summary(word,sentences=3)
        result =wikipedia.search(word)
        list = []
         #find_key= '.uk'
        for i in  result :
                list.append(i)
        print(list)
        change = json.dumps(list)



        details = str(data) + ",  we also have some suggestion which are tranding now related to  "+ str(word)+ " they are listed as" + str(change)
        print(details)
        return jsonify({'result': details})
        ''' flag = 'normal'
        for i in list:
            if i == find_key:
                flag = "found"
                print('True')
        if flag == 'found':
            details = wikipedia.summary(find_key,sentences=3)
            print(details)
            #return jsonify({'result':details})
        print(i)
        details = wikipedia.summary(word , sentences=3)
        print(details)
        return result'''


