from chatterbot.trainers import ListTrainer
from chatterbot import ChatBot
from flask import Flask, jsonify
from flask_restful import Resource, Api
from nltk.tokenize import word_tokenize
import wiki
import weather
import news_brodcast

'''
                    this is chatbot web api program you can access it any where with android, ios or any other application
                    this is basic idea how chatbot works 
                    note: for fast response you must have best GPU.
'''
app = Flask(__name__)
api = Api(app)


'''
this helps you to train data to chatbot by using  "localhost:5000/chat/"
'''
class LoadData(Resource):
    def get(self):
        bot = ChatBot('Test')
        conv1 = open('chat.txt','r').readlines()
        conv = open('weather.txt', 'r').readlines()
        conv2 = open('wiki.txt','r').readlines()
        """
        you can used for loop with OS module by importing path of directory 
        and train the chatbot with multiple file by defining for loop 
        but sometimes os path doest match for some reasons so everyone cant to
        readfile easily. so it easy way i used to times to readfile seprately. 
        """
        bot.set_trainer(ListTrainer)
        bot.train(conv)
        bot.train(conv1)
        bot.train(conv2)
        return ('Training Data Applied..!')


'''
this helps you to train data to chatbot by using  "localhost:5000/chat/query/whats your name"
in there string you pass as question after the "query/(question)"
you can check it by passing question in browser "localhost:5000/chat/query/(question)"  <----question enter hear

this gives you resoponse in json format data as replay of question.
'''


class ChatNow(Resource):

    global flag
    flag = "normal"
    def get(self, req, method =['GET']):

        global flag
        if (flag  == 'weather'):
            flag ="normal"
            return weather.Temprature.get(self, city=req)
        elif(flag == 'wiki'):
            flag = "normal"
            return wiki.Word2Data.get(self,word=req)
        elif(flag == 'news'):
            flag = "normal"
            return news_brodcast.NEWsUPdate.news_General(self)
        else:
            flag="normal"
             # Parm_req = request.args.get('req',type= str)
            bot = ChatBot('Test')
            check = word_tokenize(req)
            kk= []
            keys =['news','weather']

            for i in check:
                for j in keys:
                    if i == j:
                        print(i)
                        if i =="news":

                            key_words = ['sport', 'china', 'technology', 'tech','new your times' ,'nyt','US','America','market','business','sharemarket','wall street']
                            for a in check:
                                for b in key_words:
                                    if a == b:
                                        print(a)
                                        if a =='sport':
                                            return news_brodcast.NEWsUPdate.sport_news(self)
                                        elif a =='china':
                                            return news_brodcast.NEWsUPdate.china_news(self)
                                        elif a =='technology' or a =='tech':
                                            return news_brodcast.NEWsUPdate.tech_news(self)
                                        elif a =='nyt' or a =='US' or a=='new your times' or a =='America':
                                            return news_brodcast.NEWsUPdate.US_news(self)
                                        elif a == 'market' or a == 'business' or a == 'sharemarket' or a == 'wall street':
                                            return news_brodcast.NEWsUPdate.market_Watch(self)
                                        else:
                                            return news_brodcast.NEWsUPdate.US_news(self)
                        elif i =='weather':
                            key_words=['today','current','now','forcast']
                            for a in check:
                                for b in key_words:
                                    if a==b:
                                        if a =='today' or a =='current' or a == 'now' or 'forcast':
                                            return weather.Temprature.get(self,city='Rizhao')

                            #return news_brodcast.NEWsUPdate.news_General(self)

            response = bot.get_response(req)
            result = str(response)
            print('Client   :', req)
            print('Server   :', response)
            ChatNow.find(self,req, result)
            return jsonify({'result':result})



    def find(self, req, result):

          check = word_tokenize(result)

          key = ["city" , "wikipedia"]
          #key1 = "wikipedia"
          print(check)
          a = str(set(check) & set(key))

          print(a,type(a))
          data = a
          global flag
          if data == "{'city'}":
              flag="weather"
          elif data =="{'wikipedia'}":
              flag="wiki"
          else:
              flag="normal"

          print(flag)



"""
hear i added third party api to access data of weather of any city you can also sign in openweathermap.org
and get your appid key to use. and just replace it with your id key hear below code.
find this in code----->>>    "&appid=d4514c045821c9e1353b99cef776cae5"     <<<-----and change it with your key.
then you can access the third party API in json format
by simple accessing your web api ---> localhost:5000/weather/query/(city)  <---just add any city name you want to find.
for example------> localhost:5000/weather/query/surat
                    localhost:5000/weather/query/surat,IN   <---for more perfect and accurate result used country code
"""



api.add_resource(LoadData,'/chat')      
api.add_resource(ChatNow,"/chat/query/<req>")
api.add_resource(weather.Temprature,"/weather/query/<city>")
api.add_resource(wiki.Word2Data,"/wiki/query/<word>")

if __name__ == '__main__':
     app.run(debug=True)