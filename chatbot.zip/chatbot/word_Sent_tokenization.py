from nltk.tokenize import word_tokenize,sent_tokenize
from nltk.corpus import stopwords ,state_union
from nltk.stem import PorterStemmer
import nltk

from nltk.tokenize import PunktSentenceTokenizer

req ="python, weather of rizhao, weather of london , ahmedabad weather ,go home"
data ="hello there, whats up. the weather is great and python is awesome. tell me weather of city rizhao, tell me the weather of rizhao"
stop_Words = set(stopwords.words('english'))
words = word_tokenize(data)
filtered_Sentence = []
ookey =[]
print(data)
print('--------------stopwords-----------------')
for w in words:
    if w not in stop_Words:
        filtered_Sentence.append(w)
    if w in stop_Words:
        ookey.append(w)
print(filtered_Sentence)
print(ookey)
print('--------------stemming--------------------')
ps = PorterStemmer()
dd =[]
for w in words:
    dd.append(ps.stem(w))
print(dd)
print('-------------named entity recognition-----------------')
train_Data= state_union.raw('chat.txt')
sample_data = state_union.raw('weather.txt')
c_S_Tokenize = PunktSentenceTokenizer(train_Data)
token = c_S_Tokenize.tokenize(sample_data)

for i in token[5:]:
    wd= nltk.word_tokenize(i)
    tagg = nltk.pos_tag(wd)
    nameent = nltk.ne_chunk(tagg)
    print(nameent)
